import sys
sys.argv = [ "/home/kleberkruger/snipersim/sniper/scripts/stop-by-icount.py", "1000000000" ]
execfile("/home/kleberkruger/snipersim/sniper/scripts/stop-by-icount.py")
