import sys
sys.argv = [ "/home/kleber.kruger/donuts/sniper/scripts/stop-by-icount.py", "1000000000" ]
execfile("/home/kleber.kruger/donuts/sniper/scripts/stop-by-icount.py")
