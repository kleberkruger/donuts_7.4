import sys
sys.argv = [ "/home/kleber.kruger/PiCL/sniper/scripts/stop-by-icount.py", "1000000000" ]
execfile("/home/kleber.kruger/PiCL/sniper/scripts/stop-by-icount.py")
